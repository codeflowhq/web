"""Structure detection helpers."""
