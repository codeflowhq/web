"""Structured view builder modules."""
